package bingo.webservice.server;

import javax.jws.WebService;
import javax.xml.ws.Endpoint;


/**
 * @author RedRain
 */
@WebService
public class WSServer {
	/**
	 * @param lowwerCase
	 @return UpperCase
	 */
	//  @WebMethod
	public String upperCase(String lowwerCase){
		return lowwerCase.toUpperCase();
	}
	
	public static void main(String[] args) {
		String uri = "http://127.0.0.1:8888/ws/uppercase";
		Endpoint.publish(uri, new WSServer());
		System.out.println(uri+"?WSDL");
	}
}
