@javax.xml.bind.annotation.XmlSchema(namespace = "http://server.webservice.bingo/")
package bingo.webservice.uppercase;
