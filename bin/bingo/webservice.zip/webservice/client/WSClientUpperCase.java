package bingo.webservice.client;

import bingo.webservice.uppercase.WSServer;
import bingo.webservice.uppercase.WSServerService;

public class WSClientUpperCase {
	
	public static void main(String[] args) {
		WSServerService wSServerService = new WSServerService();
		WSServer wsServerPort = wSServerService.getWSServerPort();
		String upperCase = wsServerPort.upperCase("abcd");
		System.out.println(upperCase);
	}
}
