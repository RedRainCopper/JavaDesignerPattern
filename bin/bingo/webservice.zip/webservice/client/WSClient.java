package bingo.webservice.client;

import bingo.webservice.proxy.ArrayOfString;
import bingo.webservice.proxy.MobileCodeWS;
import bingo.webservice.proxy.MobileCodeWSSoap;

import java.util.List;

public class WSClient {
	
	public static void main(String[] args) {
		MobileCodeWS ws = new MobileCodeWS();
		MobileCodeWSSoap mobileCodeWSSoap = ws.getMobileCodeWSSoap();
		String mobileCodeInfo = mobileCodeWSSoap.getMobileCodeInfo("13512712072", "");
		System.err.println(mobileCodeInfo);
		
		ArrayOfString databaseInfo = mobileCodeWSSoap.getDatabaseInfo();
		List<String> list = databaseInfo.getString();
		for(String str : list){
			System.out.println(str);
		}
	}
}
